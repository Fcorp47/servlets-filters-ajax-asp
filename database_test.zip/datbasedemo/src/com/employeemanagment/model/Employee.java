package com.employeemanagment.model;

public class Employee {
	private int id;
	private String fname;
	private String lname;
	private String number;
	private String username;
	private String pwd;
	
	
	
	public Employee(int id, String fname, String lname, String number, String username, String pwd) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.number = number;
		this.username = username;
		this.pwd = pwd;
	}
	
	
	public Employee(String fname, String lname, String number, String username, String pwd) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.number = number;
		this.username = username;
		this.pwd = pwd;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	

}
