package com.employeemanagment.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employeemanagment.dt.Employeedat;
import com.employeemanagment.model.Employee;

public class Employees extends HttpServlet{
private Employeedat employeedao;
public Employees()
{
	employeedao=new Employeedat(); 
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	this.doGet(req, resp);
	}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action=req.getServletPath();
		switch (action) {
		case "/new": 
			ShowNewForm(req, resp);
			break;
		case "/insert":
			InsertEmployee(req, resp);
			break;
		}
		
	}
protected void ShowNewForm(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	RequestDispatcher rd = req.getRequestDispatcher("employeef.jsp");
	rd.forward(req, resp);
}
private void InsertEmployee(HttpServletRequest req, HttpServletResponse resp) throws IOException
{
	String fname=req.getParameter("txtname");
	String lname=req.getParameter("txtlname");
	String number=req.getParameter("txtnumber");
	String user=req.getParameter("txtuname");
	String pwdd=req.getParameter("txtpwd");
	
	Employee objEmployee=new Employee(fname, lname, number, user, pwdd);
	employeedao.InsertEmployee(objEmployee);
	resp.getWriter().print("insert ok");
}
}
