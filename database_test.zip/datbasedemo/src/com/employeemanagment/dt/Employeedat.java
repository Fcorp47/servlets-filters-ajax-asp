package com.employeemanagment.dt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.employeemanagment.model.Employee;

public class Employeedat {
	private String jdbcURL = "jdbc:mysql://localhost:"
			+ "3306//dat?serverTimezon=UTC";
	private String jdbcUserName="root";
	private String jdbcPassword="";
	
	private static final String INSERT_EMPLOYEE_SQL ="INSERT INTO employee (fname,lname,number,username,pwd)"
			+ "VALUES (?,?,?,?,?);";
	
	protected Connection getConnection()
	{
		Connection connection = null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection(jdbcURL,jdbcUserName,jdbcPassword);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return connection;
	}
	public void InsertEmployee(Employee objEmployee)
	{
		try(Connection connection = getConnection())
		{
			
				PreparedStatement  ps = connection.prepareStatement(INSERT_EMPLOYEE_SQL);
			    ps.setString(1, objEmployee.getFname());
			    ps.setString(2, objEmployee.getLname());
			    ps.setString(3, objEmployee.getNumber());
			    ps.setString(4, objEmployee.getUsername());
			    ps.setString(5, objEmployee.getPwd());
			    
			    ps.executeUpdate();
			    
		} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}

