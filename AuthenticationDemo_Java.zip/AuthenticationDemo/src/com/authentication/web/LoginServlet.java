package com.authentication.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.authentication.dao.UserDao;
import com.authentication.model.User;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String UserName = request.getParameter("txtUserName");
		String Password = request.getParameter("txtPassword");
		
		User objUser = new User(UserName,Password);
		UserDao objuserdao = new UserDao();
		String Role = objuserdao.AuthenticateUser(objUser);
		if(Role.equals("Admin"))
		{
			HttpSession session = request.getSession();
			session.setAttribute("Admin", UserName);
			request.getRequestDispatcher("Admin.jsp").
			forward(request, response);
		}
		else if(Role.equals("User"))
		{
			HttpSession session = request.getSession();
			session.setAttribute("User", UserName);
			request.getRequestDispatcher("User.jsp").
			forward(request, response);
		}
		else
		{
			response.setContentType("text/html");
			response.getWriter().print(Role);
			request.getRequestDispatcher("login.jsp").
			include(request, response);
		}
	}

}
