package com.authentication.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.authentication.model.User;


public class UserDao {

	private static String jdbcURI = "jdbc:mysql://localhost:3306/"
			+ "ems?serverTimezone=UTC";
	private static String jdbcusername = "root";
	private static String jdbcPassword = "";
	
	private static String LOGIN_SQL = "Select Role "
			+ "from tblUser where UserName=? and Password=?";


	protected Connection getConnection()
	{
		Connection connection=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.
					getConnection(jdbcURI,jdbcusername,jdbcPassword);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	public String AuthenticateUser(User objUser)
	{
		try(Connection connection = getConnection();)
		{
			PreparedStatement ps = connection.prepareStatement(LOGIN_SQL);
			ps.setString(1, objUser.getUsername());
			ps.setString(2, objUser.getPassword());
			
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				String Role = rs.getString("Role");
				
				if(Role.equals("Admin"))
				{
					return "Admin";
				}else if(Role.equals("User"))
				{
					return "User";
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Invalid User Credentials";
	}
}
