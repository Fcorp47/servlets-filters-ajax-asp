package com.rest.crud.api;

import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

@Path("/products")
public class productResource {

	ProductDao dao = new ProductDao();
	
	  @POST
	  @Path("/add") 
	  @Consumes(MediaType.APPLICATION_JSON)
	  @Produces(MediaType.TEXT_PLAIN)
	  public String AddProduct(Product product) throws SQLException, JsonMappingException, JsonProcessingException {
		 
		 int r = dao.AddUser(new Product(product.getName(),product.getPrice())); 
		 if(r > 0) 
			 return "Product Added successfully"; 
		 else 
			 return "Error in insert";
		
	  }
	 
	
	  @POST
	  @Path("/update")
	  @Consumes(MediaType.APPLICATION_JSON)
	  @Produces(MediaType.TEXT_PLAIN)
	  public String UpdateProduct(Product product) throws SQLException
	  {
		  System.out.println(product.getId());
		  int r = dao.UpdateUser(new Product(product.getId(),product.getName(),product.getPrice())); 
			 if(r > 0) 
				 return "Product Updated successfully"; 
			 else 
				 return "Error in update";
	  }
	  
	  @GET
	  @Path("/delete")
	  @Produces(MediaType.APPLICATION_JSON)
	  public String DeleteProduct(@QueryParam("id") int id) throws SQLException
	  {
		  //System.out.println(product.getId());
		  int r = dao.DeleteProduct(id); 
		 if(r > 0) 
			 return "Product deleted successfully"; 
		 else 
			 return "Error in delete";
	  }
/*
 * @POST
 * 
 * @Produces(MediaType.TEXT_HTML)
 * 
 * @Consumes(MediaType.APPLICATION_FORM_URLENCODED) public Response
 * AddProduct(@FormParam("txtProductName") String name,
 * 
 * @FormParam("txtPrice") float Price) throws SQLException {
 * System.out.println(name);
 * 
 * int r = dao.AddUser(new Product(name,Price)); if(r > 0) return
 * Response.status(200).entity("Product Added successfully").build(); else
 * return Response.status(200).entity("Error").build(); }
 */
	
	@GET
	@Path("/list")
	@Produces(MediaType.APPLICATION_JSON)
	public String GetProducts() throws SQLException
	{
		List<Product> list = dao.GetAllProducts();
	
		return new Gson().toJson(list);
		
	}
	
	@GET
	@Path("/edit")
	@Produces(MediaType.APPLICATION_JSON)
	public String GetProductDetails(@Context UriInfo uriinfo) throws SQLException
	{
		int id = Integer.parseInt(uriinfo.getQueryParameters().getFirst("id"));
		Product objProduct = dao.GetDetails(id);
		
		return new Gson().toJson(objProduct);
		
	}
}
