package com.rest.crud.api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDao {

	private static String jdbc_url = "jdbc:mysql://localhost:3306/ems?serverTimezone=UTC";
	private static String jdbc_username = "root";
	private static String jdbc_password = "";
	private static String INSERT_SQL = "INSERT INTO tblproduct(name,price) VALUES (?,?)";
	private static String SELECT_SQL = "SELECT * FROM tblproduct";
	private static String DETAILS_SQL = "SELECT * FROM tblproduct WHERE id=?";
	private static String UPDATE_SQL = "UPDATE tblproduct SET name=?, price=? WHERE id=?";
	private static String DELETE_SQL = "DELETE FROM tblproduct WHERE id=?";
	public Connection getConnection()
	{
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbc_url,jdbc_username,jdbc_password);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	public int AddUser(Product objProduct) throws SQLException
	{
		try(Connection cn = getConnection();)
		{
			PreparedStatement ps = cn.prepareStatement(INSERT_SQL);
			ps.setString(1, objProduct.getName());
			ps.setFloat(2, objProduct.getPrice());
			
			int r = ps.executeUpdate();
			return r;
		}
	}
	
	public int UpdateUser(Product objProduct) throws SQLException
	{
		try(Connection cn = getConnection();)
		{
			PreparedStatement ps = cn.prepareStatement(UPDATE_SQL);
			ps.setString(1, objProduct.getName());
			ps.setFloat(2, objProduct.getPrice());
			ps.setInt(3, objProduct.getId());
			
			int r = ps.executeUpdate();
			return r;
		}
	}
	
	public int DeleteProduct(int id) throws SQLException
	{
		try(Connection cn = getConnection();)
		{
			PreparedStatement ps = cn.prepareStatement(DELETE_SQL);
			ps.setInt(1, id);
			
			int r = ps.executeUpdate();
			return r;
		}
	}
	
	public List<Product> GetAllProducts() throws SQLException
	{
		List<Product> productList = new ArrayList<>();
		try(Connection cn = getConnection();)
		{
			PreparedStatement ps = cn.prepareStatement(SELECT_SQL);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt("id");
				String name = rs.getString("name");
				float price = rs.getFloat("price");
				productList.add(new Product(id,name,price));
			}
		}
		
		return productList;
	}
	
	public Product GetDetails(int id) throws SQLException
	{
		Product objProduct = null;
		try(Connection cn = getConnection();)
		{
			PreparedStatement ps = cn.prepareStatement(DETAILS_SQL);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				
				String name = rs.getString("name");
				float price = rs.getFloat("price");
				objProduct = new Product(id, name, price);
			}
		}
		return objProduct;
	}
}
