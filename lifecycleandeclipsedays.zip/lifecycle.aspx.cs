﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace registration
{
    public partial class lifecycle : System.Web.UI.Page
    {
        protected void Page_PreInit(object sender, EventArgs e)
        {
            Response.Write("page pre init <br>");
        }
        protected void Page_Init(object sender, EventArgs e)
        {
            Response.Write("page init <br>");
        }

        protected void Page_InitComplete(object sender, EventArgs e)
        {
            Response.Write("page init complete <br>");
        }
        protected void Page_PreLoad(object sender, EventArgs e)
        {
            Response.Write("page pre load <br>");
        }
     
          protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("page load <br>");
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            Response.Write("page load complete <br>");
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            Response.Write("page prerender <br>");
        }
        protected void Page_PreRenderComplete(object sender, EventArgs e)
        {
            Response.Write("page prerender complete <br>");
        }



    }
}