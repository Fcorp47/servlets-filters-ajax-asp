package com.ajax.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ajax.model.User;

public class UserDao {
	private static String jdbcUrl = "jdbc:mysql://localhost:3306/ems?serverTimezone=UTC";
	private static String jdbcUsername = "root";
	private static String jdbcPassword = "";
	
	private static String INSERT_SQL = "INSERT INTO tbluser (Name, UserName, Password, Role) VALUES (?,?,?,?);";
	private static String SELECT_SQL = "SELECT * FROM tbluser";
	private static String DETAILS_SQL = "SELECT * FROM tbluser Where ID=?";
	private static String UPDATE_SQL = "UPDATE tbluser SET Name=?, UserName=? WHERE ID=?";
	private static String DELETE_SQL = "DELETE from tbluser WHERE ID=?";
	
	protected Connection getConnection()
	{
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcUrl,jdbcUsername,jdbcPassword);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	public int InsertUser(User objUser)
	{
		int result = 0;
		try(Connection connection = getConnection();)
		{
			PreparedStatement ps = connection.prepareStatement(INSERT_SQL);
			ps.setString(1, objUser.getName());
			ps.setString(2, objUser.getUsername());
			ps.setString(3, objUser.getPassword());
			ps.setString(4, objUser.getRole());
			
			int r = ps.executeUpdate();
			if(r > 0)
				result = r;
			else
				result = -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public int UpdateUser(User objUser)
	{
		int result = 0;
		try(Connection connection = getConnection();)
		{
			PreparedStatement ps = connection.prepareStatement(UPDATE_SQL);
			ps.setString(1, objUser.getName());
			ps.setString(2, objUser.getUsername());
			ps.setInt(3, objUser.getId());
			
			
			int r = ps.executeUpdate();
			if(r > 0)
				result = r;
			else
				result = -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public int DeleteUser(int ID)
	{
		int result = 0;
		try(Connection connection = getConnection();)
		{
			PreparedStatement ps = connection.prepareStatement(DELETE_SQL);
			
			ps.setInt(1, ID);
			
			
			int r = ps.executeUpdate();
			if(r > 0)
				result = r;
			else
				result = -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	public List<User> GetUserList()
	{
		ArrayList<User> userlist = new ArrayList<>();
		try(Connection connection = getConnection();)
		{
			PreparedStatement ps = connection.prepareStatement(SELECT_SQL);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				int Id = rs.getInt("ID");
				String name = rs.getString("Name");
				String UserName = rs.getString("UserName");
				String Password = rs.getString("Password");
				String Role = rs.getString("Role");
				userlist.add(new User(Id,name,UserName,Password,Role));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userlist;
	}
	public User GetDetails(int userID)
	{
		User objUser = null;
		try(Connection connection = getConnection();)
		{
			PreparedStatement ps = connection.prepareStatement(DETAILS_SQL);
			ps.setInt(1, userID);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				
				String name = rs.getString("Name");
				String UserName = rs.getString("UserName");
				String Password = rs.getString("Password");
				String Role = rs.getString("Role");
				objUser = new User(userID, name, UserName, Password, Role);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return objUser;
	}
}
