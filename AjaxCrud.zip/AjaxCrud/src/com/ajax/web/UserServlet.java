package com.ajax.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ajax.dao.UserDao;
import com.ajax.model.User;
import com.google.gson.Gson;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonWriter;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDao objUserDao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
       objUserDao = new UserDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * String action = request.getServletPath(); System.out.println(action);
		 * switch(action) { case "/new": showNewForm(request,response); break; case
		 * "/AddUser": InsertUser(request, response); break; }
		 */
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		System.out.println(action);
		if(action != null)
		{
			if(action.equals("AddUser"))
			{
				InsertUser(request, response);
			}else if(action.equals("list"))
			{
				ListUsers(request, response);
			}else if(action.equals("edit"))
			{
				EditUser(request,response);
			}else if(action.equals("UpdateUser"))
			{
				UpdateUser(request, response);
			}
			else if(action.equals("DeleteUser"))
			{
				DeleteUser(request, response);
			}
		}
	}

	private void DeleteUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		int ID = Integer.parseInt(request.getParameter("id"));
		int result = objUserDao.DeleteUser(ID);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if(result > 0)
		{
			out.print("User Deleted Successfully");
		}
		else
		{
			out.print("Error occured in deletion");
		}
		out.flush();
		out.close();
	}

	private void EditUser(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			int ID = Integer.parseInt(request.getParameter("id"));
			User objUser = objUserDao.GetDetails(ID);
			System.out.println("ID : " + ID);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
		
			
			out.print(new Gson().toJson(objUser));
			//out.print(objUser.getName());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("Add.jsp");
		rd.forward(request, response);
	}
	
	private void InsertUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Name = request.getParameter("name");
		System.out.println(Name);
		String UName = request.getParameter("UName");
		String Password = request.getParameter("Password");
		String Role = "User";
		
		User objUser = new User(Name, UName, Password, Role);
		int r = objUserDao.InsertUser(objUser);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if(r > 0)
		{
			out.print("User Added Successfully");
		}
		else
		{
			out.print("Error occured in insertion");
		}
		out.flush();
		out.close();
	}
	
	private void UpdateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Name = request.getParameter("name");
		System.out.println(Name);
		String UName = request.getParameter("UName");
		
		int Id = Integer.parseInt(request.getParameter("id"));
		User objUser = new User(Id, Name, UName);
		int r = objUserDao.UpdateUser(objUser);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if(r > 0)
		{
			out.print("User Updated Successfully");
		}
		else
		{
			out.print("Error occured in insertion");
		}
		out.flush();
		out.close();
	}
	
	private void ListUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Gson gson = new Gson();
		List<User> userlist = objUserDao.GetUserList();
		response.setContentType("text/html");
		response.getWriter().print(gson.toJson(userlist));
		
	}
}
