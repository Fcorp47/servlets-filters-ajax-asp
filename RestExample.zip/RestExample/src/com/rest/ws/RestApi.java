package com.rest.ws;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

@Path("/api")
public class RestApi {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/hello")
	public String getMessage()
	{
		return "Hello World";
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{name}")
	public String getNameFromURL(@PathParam("name") String name)
	{
		return "Good morning " + name;
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{year}/{month}/{date}")
	public String getDate(@PathParam("year") int year,
			@PathParam("month") int month,
			@PathParam("date") int date) {
		return "Date is : " + date + "/" + month + "/" + year;
	}
	
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/add")
	public String AddValues(@FormParam("txtNo1") int No1,
			@FormParam("txtNo2") int No2)
	{
		int result = No1 + No2;
		return "Addition of two numbers is : " + result;
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/query")
	public String getQueryStringValue(@QueryParam("name") String name,
			@QueryParam("lastname") String lastname)
	{
		return "Parameter 1 : " + name + "\n Parameter 2 : " + lastname;
	}
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/context")
	public String getQueryStringValueusingContext(@Context 
			UriInfo uriinfo)
	{
		String name = uriinfo.getQueryParameters().getFirst("name");
		return "Parameter 1 : " + name;
	}
}
